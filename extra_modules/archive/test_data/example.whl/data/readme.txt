This is the xff archive fixture.
findable-needle
