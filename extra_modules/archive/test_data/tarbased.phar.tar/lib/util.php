<?php
function xff_fixture_main(): void {
    // padding padding padding padding padding padding padding
    // padding padding padding padding padding padding padding
    echo "xff phar fixture\n";
}
