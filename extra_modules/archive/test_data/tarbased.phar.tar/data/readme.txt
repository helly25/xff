This is the xff phar fixture.
findable-needle
